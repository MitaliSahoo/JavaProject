-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 01, 2018 at 03:36 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bank`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_no` int(11) DEFAULT NULL,
  `fname` varchar(40) NOT NULL,
  `lname` varchar(40) DEFAULT NULL,
  `gender` varchar(1) DEFAULT NULL,
  `account_type` varchar(1) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `phone_no` varchar(11) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account_no` (`account_no`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`id`, `account_no`, `fname`, `lname`, `gender`, `account_type`, `address`, `phone_no`, `amount`) VALUES
(1, 123, 'Mitali', 'Sahoo', 'f', 's', 'Address', '987654321', 1500),
(2, 111, 'John', 'C', 'm', 's', 'Address', '745836142', 1000),
(3, 456, 'Pooja', 'S', 'f', 's', 'Address', '987546213', 2500),
(4, 147, 'Ajay', 'S', 'm', 'c', 'Address', '7541236548', 3500);
